import requests
from bs4 import BeautifulSoup
import json
import csv
import time
import re
from datetime import datetime
from geopy.geocoders import Nominatim
from jinja2 import Environment, FileSystemLoader
from dotenv import load_dotenv
import os
import random
from blogger_api import Blogger_Api
from datetime import datetime, timezone
from datetime import datetime, timezone, timedelta

# Load the .env file
load_dotenv()


class Job:
    level_pattern = r"This is a <b>(.*?)</b>"
    try:
        api_key = os.getenv("SCRAPER_API_KEY")
    except:
        api_key = "23bf5c839fd417c0e3de020aa6b7b7a1"

    api_url = "http://api.scraperapi.com"
    data = []
    storage_json = "templates\storage.json"

    def __init__(self, enable_post=False):
        """
        Initializes the Job object with a base URL.
        The base URL is used as the starting point for fetching job postings. It can be cannot be overridden to point to a different job listing website.
        """
        self.enable_post = enable_post
        self.base_url = "https://untalent.org/jobs/"
        self.history = self.read_from_json(self.storage_json)
        self.counter = self.read_from_json("templates\counter.json")
        if not self.counter:
            self.counter = {"counter": 1000}

    def has_date_passed(self, date_str):
        try:
            # Parse the input date string into a datetime object (offset-aware)
            input_date = datetime.fromisoformat(date_str)
            # Get the current date and time (offset-aware)
            current_date = datetime.now(timezone.utc)
            # Check if the input date is in the past
            return input_date < current_date
        except:
            return False

    def clean_json_string(self, json_string):
        # Replace triple double quotes with single double quotes
        json_string = re.sub(r'"""', '"', json_string)
        # Escape double quotes within the JSON string
        json_string = re.sub(r"\\", r"\\\\", json_string)
        json_string = re.sub(r"\"", r'\\"', json_string)
        json_string = re.sub(r'\\\\\\"', r'\\\\"', json_string)  # Fix double escape

        return json_string

    def get_direct_apply_link(self, url):
        # Headers
        headers = {
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-User": "?1",
            "Te": "trailers",
        }

        # Cookies
        cookies = {
            "PHPSESSID": "40tjk03m3c88847ph5oafc1c90a4nl0i",
            "REMEMBERME": "UHJveGllc1xfX0NHX19cQXBwXEVudGl0eVxVc2VyOmVIUnpZbTlzZEdWQVoyMWhhV3d1WTI5dDoxNzQ3NjQxOTY3OmZkNTFhMzY4NjRmNGU0OWIxY2IzNzIyZjIwNjExNWE3NTA3NmFhOTU3ZmRjZTg5YTk2NzEzZWVlMjE2YTBkY2Q%3D",
        }

        # Make the GET request
        response = requests.get(url + "/apply", headers=headers, cookies=cookies)
        # Check if the request was successful

        if not "untalent.org" in str(response.url):
            return response.url
        else:
            print(f"fail to get the direct apply link : {url}")
            return url

    def set_templates_jinja(self, O_data):
        scrape_data = O_data
        # scrape_data["job_description_HTML"]= scrape_data["job_description_HTML"].replace("\n", "\\n")
        # cSet up the Jinja2 environment
        file_loader = FileSystemLoader("templates")
        env = Environment(loader=file_loader)
        templates_name = "job_template.html"

        if scrape_data["position_info"] == "TELECOMUTE":
            templates_name = "remote_job_templates.html"

        # Load the template
        template = env.get_template(templates_name)

        # Data to fill the template
        data = {"data": scrape_data}

        # Render the template with the data
        output = template.render(data)
        job_id = scrape_data["JobId"]
        with open(f"jobs_html_results/{job_id}.html", "w", encoding="utf-8") as f:
            f.write(output)

        return output

    def update_counter(self):
        """
        Increments the job counter by 1 and updates the corresponding JSON file.

        This method is responsible for tracking the number of jobs processed. It increments the counter stored in the class's `counter` attribute, then writes the updated counter value to a JSON file named "counter.json". This ensures that the counter persists across program executions.

        Returns:
            int: The updated counter value after incrimination.
        """
        self.counter["counter"] += 1
        self.write_to_json(self.counter, "templates\counter.json")
        return self.counter["counter"]

    def append_data_to_json_list(self, data, file_path="storage.json"):
        """
        Appends a given data item to a list in a JSON file. If the file does not exist or is empty,
        a new list with the data item is created. If the data item already exists in the list,
        it is not added again to prevent duplicates.

        Parameters:
        - data: The data item to be added to the JSON list. This can be any data type that is
                serializable to JSON, such as a dictionary.
        - file_path (str, optional): The path to the JSON file where the data item is to be appended.
                                    Defaults to "storage.json".

        Returns:
        - data_dict (list): The updated list of data items after appending the new item,
                            read back from the JSON file.

        Note:
        - This method checks for the existence of the file and its content's validity before attempting
        to append to it. If the file does not exist or contains invalid JSON, a new list with the
        provided data item is created.
        - The method has a logical error in the condition `if not data in data:` which always evaluates
        to False. This condition should likely be revised to correctly check for the existence of
        the `data` item within `data_dict`.
        """
        data_dict = []
        try:
            with open(file_path, "r") as file:
                data_dict = json.load(file)
        except:
            data_dict = []

        if not data in data_dict:
            data_dict.append(data)

        with open(file_path, "w") as file:
            json.dump(data_dict, file, indent=4)

        return data_dict

    def format_date_time(self, original_date_string, page_source):
        """
        Converts a date string from ISO 8601 format to a more readable format.

        This method takes a date string in the ISO 8601 format (e.g., "2023-01-01T12:00:00+00:00") and converts it into a more user-friendly date format ("dd-Mon-yy"). If the conversion fails due to an incorrect format or any other reason, it returns an empty string.

        Parameters:
        - original_date_string (str): The original date string in ISO 8601 format.
        - page_source (str): The source of the page from which the date is extracted. This parameter is currently not used in the function but could be utilized for logging or handling different formats based on the source.

        Returns:
        - str: The formatted date string in "dd-Mon-yy" format or an empty string if the conversion fails.
        """
        try:
            # Parse the original date string into a datetime object
            original_date = datetime.strptime(
                original_date_string, "%Y-%m-%dT%H:%M:%S%z"
            )
            # Convert the datetime object to the desired format
            return original_date.strftime("%d-%b-%y")
        except:
            return ""

    def random_wait(self, min=5, max=14):
        sleep = random.randint(min, max)
        time.sleep(sleep)
        return True

    def get_data_from_all_pages(self, links):
        data = self.iterate_links(links)
        return data

    def find_jobs_links(self, max_pages=4):
        """
        Fetches job posting links from the base URL across multiple pages.
        This method navigates through a specified number of pages on the job listing website, extracting the URLs of individual job postings. It constructs the URL for each page by appending the page number to the base URL, sends a GET request to retrieve the page content, and then parses the HTML to find job posting links.
        Parameters:
        - max_pages (int): The maximum number of pages to search through for job links. Defaults to 2.
        Returns:
        - list: A list of URLs (strings) for each job posting found across all pages searched. Returns an empty list if an error occurs or if no job postings are found.
        Exceptions:
        - Prints any exceptions encountered during the process to the console.
        """
        jobs = []
        final_extracted_data = []
        try:
            for page in range(1, max_pages + 1):
                print(f"Getting job posting from {page} Page...")
                print()
                try:
                    url = self.base_url + f"?page={page}"
                    response = requests.get(url)
                    soup = BeautifulSoup(response.text, "html.parser")
                    job_cards = soup.find_all(class_="job card")
                    if not job_cards:
                        job_cards = BeautifulSoup(
                            self.backup_fetcher(url).text, "html.parser"
                        ).find_all(class_="job card")
                    job = [
                        f.find(class_="content").find("h4").find("a").get("href")
                        for f in job_cards
                    ]
                    filter_job = []
                    for link in job:
                        if not link in self.history:
                            filter_job.append(link)

                    jobs.extend(filter_job)
                    extracted_data = self.get_data_from_all_pages(filter_job)
                    final_extracted_data.extend(extracted_data)
                    self.write_to_csv(extracted_data, "jobs.csv")
                    if max_pages > 1:
                        self.random_wait()
                except Exception as e:
                    print(e)
                    pass
            return jobs, final_extracted_data

        except Exception as e:
            return []

    def get_job_details(self, job_url):
        if job_url not in self.history:
            self.history.append(job_url)

        print(f"Getting job details from : %s" % job_url)
        """
        Fetches and extracts details of a specific job from its webpage.
        This method sends a GET request to the provided job URL, parses the HTML content to extract job details such as the job title, application link, company name, position information, company logo, job location, and job description.
        Parameters:
        - job_url (str): The URL of the job page from which to extract details.
        Returns:
        - dict: A dictionary containing the extracted job details. Keys include 'job_title', 'apply_link', 'company_name', 'position_info', 'logo', 'location', and 'job_description'. If an error occurs during the process, an empty dictionary is returned.
        Exceptions:
        - Prints any exceptions encountered during the process to the console.
        """
        job_info = ""
        r = ""
        state_country = ""
        hiringOrganization = {}
        jumbo = ""
        try:

            r = requests.get(job_url)
            job_page = BeautifulSoup(r.text, "html.parser")
            try:
                job_info = json.loads(
                    job_page.find("script", type="application/ld+json").text
                )
            except:
                job_info = None

            if not job_info:
                r = self.backup_fetcher(job_url)
                job_page = BeautifulSoup(r.text, "html.parser")
                job_info = json.loads(
                    job_page.find("script", type="application/ld+json").text
                )
            _type = job_info.get("@type", None)
            datePosted = job_info.get("datePosted", None)
            title = job_info.get("title", None)
            description = job_info.get("description", None)
            salaryCurrency = job_info.get("salaryCurrency", None)
            url = job_info.get("url", None)
            validThrough = job_info.get("validThrough", None)
            
            if not validThrough:
                current_time_utc = datetime.now(timezone.utc)
                future_time_utc = current_time_utc + timedelta(days=30)
                validThrough = future_time_utc.isoformat()
                
            if self.has_date_passed(validThrough):
                return 

                
            
            employmentType = job_info.get("employmentType", None)
            employmentType_capitalize = ""
            # input(employmentType)
            if employmentType:
                employmentType = employmentType[0]
                job_info["employmentType"] = employmentType.replace("-", "_")

            if employmentType:
                employmentType_capitalize = employmentType.capitalize()

            job_location_list = job_info.get("jobLocation")
            if job_location_list:
                location_dict = job_location_list[0]
            else:
                location_dict = {}

            location_type = location_dict.get("@type", None)
            location_name = location_dict.get("name", None)
            location_address = location_dict.get("address", {})
            location_address_type = location_address.get("@type", None)
            location_addressLocality = location_address.get("addressLocality", None)
            location_addressCountry = location_address.get("addressCountry", None)

            jobLocationType = job_info.get("jobLocationType", None)

            hiringOrganization = job_info.get("hiringOrganization", {})
            hiringOrganization_type = hiringOrganization.get("@type", None)
            hiringOrganization_name = hiringOrganization.get("name", None)
            hiringOrganization_logo = hiringOrganization.get("logo", None)
            try:

                short_company_name = hiringOrganization_name.split("-")[0]
                long_company_name = hiringOrganization_name.split("-")[1]
            except:
                short_company_name = hiringOrganization_name
                long_company_name = hiringOrganization_name
            # formatted_description = self.get_formatted_description(
            #     description, validThrough, job_info, hiringOrganization_logo, url
            # )
            # postToBlogger(title, "", formatted_description, labels=None,expiredDate=validThrough)
            level = None
            match = re.search(self.level_pattern, str(job_page))
            if match is not None:
                level = match.group(1)
            else:
                level = ""

            tags_list = [t.text for t in job_page.find_all(class_="tag")]
            tags = ", ".join(tags_list)
            locations_div = job_page.find(class_="locations")
            state_country = locations_div.find_all("a")

            if state_country:
                try:
                    state = state_country[0].text
                    country = state_country[1].text
                except:
                    country = state_country[0].text
            else:
                state = ""
                country = ""

            if country == "United States of America":
                country = "United States"

            estimatedSalary = "0"
            try:
                estimatedSalary = job_info["estimatedSalary"]
            except:
                pass

            description_html = str(
                job_page.find(class_="card partner").find_next_sibling()
            )

            extract_company_info = self.extract_information(
                company_name=hiringOrganization_name,
                addressLocality=location_addressLocality,
                country_code=location_addressCountry,
            )
            postal_code = "00000"
            try:
                postal_code = extract_company_info["address"]["postcode"]
            except Exception as e:
                pass
            try:
                state = extract_company_info["address"]["state"]
            except:
                pass
            try:
                location_addressCountry = extract_company_info["address"]["country"]
            except:
                pass

            region = state
            try:
                region = extract_company_info["address"]["region"]
            except:
                pass
            try:
                region = extract_company_info["address"]["state"]
            except:
                pass

            street = state

            try:
                street = extract_company_info["address"]["road"]
            except:
                pass

            self.write_to_json(self.history, self.storage_json)
            short_company_name = str(
                short_company_name.lower().replace("-", "").lower().replace("_", "")
            ).strip()
            job_id = self.update_counter()
            job_description_json = self.clean_json_string(description_html).replace("\n", "  ")

            same_as = f"https://www.unjoble.org/p/{short_company_name}.html".replace(" ", "-").replace("  ", "-")
            job_info["url"] = same_as
            data = {
                "JobId": job_id,
                "title": title,
                "apply_link": self.get_direct_apply_link(url),
                "samsAs": same_as,
                "Level": level,
                "Category": tags,
                "company_name": hiringOrganization_name,
                "company_short": short_company_name,
                "company_long": long_company_name,
                "position_info": employmentType.replace("_", "-"),
                "employmentType_schema": employmentType,
                "Employment Type": employmentType_capitalize.replace("_", "-"),
                "logo": hiringOrganization_logo,
                "location_city": state,
                "location_country": country,
                "job_description": job_description_json,
                "job_description_HTML": description_html,
                # "formatted_description": formatted_description,
                "Date Posted": self.format_date_time(datePosted, "date_posted"),
                "datePosted": datePosted,
                "Deadline": self.format_date_time(validThrough, "date_deadline"),
                "validThrough": validThrough,
                "salaryCurrency": salaryCurrency,
                "salaryMin": "0",
                "salaryMax": estimatedSalary,
                "location_type": location_type,
                "location_name": location_name,
                "location_street": street,
                "location_region": region,
                "location_address_type": location_address_type,
                "location_addressLocality": location_addressLocality,
                "location_addressCountry": location_addressCountry,
                "location_postCode": postal_code,
                "hiringOrganization_type": hiringOrganization_type,
                "hiringOrganization_name": hiringOrganization_name,
                "hiringOrganization_logo": hiringOrganization_logo,
                "jobLocationType": jobLocationType,
                "schemaScript": job_info,
                "template": "",
            }

            html_temples = str(self.set_templates_jinja(data))
            if self.enable_post:
                Blogger_Api()

            return data

        except Exception as e:
            return {}

    def extract_information(
        self, company_name, addressLocality=None, country_code=None
    ):
        try:
            geolocator = Nominatim(
                user_agent="Mozilla/5.0 (X11; CrOS x86_64 8172.45.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.64 Safari/537.36"
            )
            query = {"q": company_name}
            if addressLocality:
                query["city"] = addressLocality
            if country_code:
                query["country"] = country_code
            if not addressLocality and not country_code:
                query = company_name

            location = geolocator.geocode(company_name, addressdetails=True)
            if location:
                return location.raw
            else:
                return {}
        except:
            return {}

    def write_to_json(self, data, json_file):
        """
        Writes the provided data to a JSON file.
        The function opens the specified JSON file in write mode and writes the data to it as JSON.
        Parameters:
        - data (list): A list of dictionaries, where each dictionary represents a row of data to be written to the JSON file. Each dictionary must have the same keys.
        - json_file (str): The name of the JSON file to write the data to.
        Returns:
        - bool: Returns True if the data is successfully written to the JSON file, otherwise returns False.
        Raises:
        - IOError: If there is an error opening or writing to the JSON file.
        """

        try:
            with open(json_file, "w", encoding="utf-8") as json_file:
                json.dump(
                    data, json_file, indent=4
                )  # Write data to JSON file with indentation for readability
            return True
        except Exception as e:
            return False

    def read_from_json(self, json_file):
        """
        Reads data from a JSON file.
        The function opens the specified JSON file in read mode and reads the data from it.
        Parameters:
        - json_file (str): The name of the JSON file to read the data from.
        Returns:
        - data (list): A list of dictionaries containing the data read from the JSON file.
        - If the file cannot be opened or there is an error reading the data, returns an empty list.
        """
        try:
            with open(json_file, "r", encoding="utf-8") as json_file:
                data = json.load(json_file)  # Read data from JSON file
            return data
        except IOError:
            return []

    def iterate_links(self, links):
        """
        Iterates over a list of job posting URLs, fetches job details for each, and appends the details to the class's data list.
        This method takes a list of URLs pointing to individual job postings, retrieves detailed information for each job by calling the `get_job_details` method, and appends the resulting dictionary of job details to the `data` attribute of the class if the dictionary is not empty.
        Parameters:
        - links (list): A list of strings, where each string is a URL to a job posting.
        Returns:
        - list: A list of dictionaries, where each dictionary contains details of a job posting. This list is also stored in the class's `data` attribute.
        """
        data = []
        for link in links:
            try:
                d = self.get_job_details(link)
                if d:
                    data.append(d)
                    self.random_wait()
            except KeyboardInterrupt as e:
                return data
        return data

    def backup_fetcher(self, url):
        """
        Sends a GET request to a proxy service to fetch the content of a webpage.

        This method is used as a fallback mechanism to retrieve web page content when direct requests fail or are blocked by the target website. It utilizes a proxy service, identified by `self.api_url`, passing the target URL and an API key for authentication.

        Parameters:
        - url (str): The URL of the web page to fetch.

        Returns:
        - response (requests.Response): The response object from the proxy service, which includes the status code, headers, and the content of the fetched web page.
        """
        payload = {"api_key": self.api_key, "url": url, "render": "true"}
        response = requests.get(self.api_url, params=payload)
        return response

    def read_from_csv(self, csv_file):
        """
        Reads data from a CSV file and returns it as a list of dictionaries.

        Parameters:
        csv_file (str): The name of the CSV file to read from.

        Returns:
        list: A list of dictionaries, where each dictionary represents a row in the CSV file.
              If the file cannot be opened or there is an error reading the data, returns an empty list.
        """
        data = []
        try:
            with open(csv_file, "r", newline="", encoding="utf-8") as file:
                reader = csv.DictReader(file)
                for row in reader:
                    data.append(dict(row))
        except:
            data = []
        return data

    def write_to_csv(self, new_data, csv_file="Jobs.csv"):
        # if not new_data:
        #     return

        """
        Writes new data to a CSV file, appending it to any existing data.

        This method reads existing data from the specified CSV file into a list of dictionaries,
        extends this list with new data provided, and then writes the combined data back to the CSV file.
        It ensures that the CSV file contains a header row with field names derived from the keys of the
        first dictionary in the data list.

        Parameters:
        - new_data (list): A list of dictionaries where each dictionary represents a row to be added to the CSV file.
        - csv_file (str): The path to the CSV file where data is to be written.

        Returns:
        - bool: True if the data was successfully written to the CSV file, False otherwise.
        """
        data = self.read_from_csv(csv_file)
        data.extend(new_data)
        self.write_to_json(data,"JOBS.json")
        with open(csv_file, "w", newline="", encoding="utf-8") as csv_file:
            fieldnames = data[0].keys()  # Getting field names from the first dictionary
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            writer.writeheader()  # Write header with field names
            for row in data:
                writer.writerow(row)
            return True
    


if __name__ == "__main__":
    J = Job(enable_post=True)
    job_links, data = J.find_jobs_links(2)
    if job_links:
        print(f"Total Job Scrape: %s" % len(job_links))
