import httplib2
from oauth2client.client import flow_from_clientsecrets
from oauth2client.file import Storage
from oauth2client.tools import run_flow
from googleapiclient import discovery
import csv,os
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()


class Blogger_Api:
    def __init__(self,title, html, labels=None, expiredDate=None, identifier=None):
        try:
            self.postToBlogger(title, html, labels=None, expiredDate=None, identifier=None)
        except Exception as e:
            print(e)
        
    def authorize_credentials(self, CLIENT_SECRET="client_secret.json"):
        SCOPE = "https://www.googleapis.com/auth/blogger"
        STORAGE = Storage("credentials.storage")
        # Fetch credentials from storage
        credentials = STORAGE.get()
        # If the credentials doesn't exist in the storage location then run the flow
        if credentials is None or credentials.invalid:
            flow = flow_from_clientsecrets(CLIENT_SECRET, scope=SCOPE)
            http = httplib2.Http()
            credentials = run_flow(flow, STORAGE, http=http)
        return credentials

    def getBloggerService(self):
        credentials = self.authorize_credentials()
        http = credentials.authorize(httplib2.Http())
        discoveryUrl = "https://blogger.googleapis.com/$discovery/rest?version=v3"
        service = discovery.build(
            "blogger", "v3", http=http, discoveryServiceUrl=discoveryUrl
        )
        return service

    def postToBlogger(
        self, title, html, labels=None, expiredDate=None, identifier=None
    ):
        payload = {
            "content": html,
            "title": title,
            "labels": labels,
        }

        service = self.getBloggerService()
        post = service.posts()
        insert = {}
        
        e = post.insert(blogId=os.getenv("BLOGGER_ID"), body=payload).execute()["id"]
        insert["id"] = e
        insert["expiredDate"] = expiredDate
        print(f"Posted: {identifier} with postid: {e}")
        self.insert_to_csv("isBlogExpired.csv", insert)
        return insert

    def insert_to_csv(data, csv_file="Blogger_info.json"):
        try:
            file_exists = os.path.isfile(csv_file)
            mode = "a" if file_exists else "w"
            with open(csv_file, mode, newline="", encoding="utf-8") as file:
                fieldnames = data.keys()
                writer = csv.DictWriter(file, fieldnames=fieldnames)
                if not file_exists:  # If file doesn't exist, write header
                    writer.writeheader()
                writer.writerow(data)
            return True
        except IOError:
            return False
